# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.


from ..shared.reasoning_effort import ReasoningEffort

__all__ = ["ChatCompletionReasoningEffort"]

ChatCompletionReasoningEffort = ReasoningEffort
